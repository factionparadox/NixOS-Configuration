#!/bin/bash


# Get the year.
year=$(date +"%Y")

# Output the year.
echo "$year"
