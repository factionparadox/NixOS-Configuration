# diinki aero Taskbar
The taskbar for the diinki aero rice. I use Waybar for the 
taskbar as it has many features, is easy to theme/design, and 
in general works quite well.

The taskbar has two versions, one is opaque, and one is transparent.
Make sure to configure the hyprland theme correctly in order to have
background-blur work.

If you use the hyprland config that is native to the diinki-aero theme,
then everything should work.
