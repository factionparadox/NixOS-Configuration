# Icon Theme

The icon theme I used is: [fairy wren](https://diinki.com), it's updated often and matches the
theme well-ish; feel free to browse around and use your own icon theme.
