# diinki aero Hyprland config
I've decided to use Hyprland as the tiling window manager of choice for the
'diinki aero' rice. 

These are the config files, everything is well commented, so take a look and
customize everything to your liking.
