# diinki retro dark

This is a collection of gtk themes made for my simplistic, retro-futuristic linux rices.
The gtk themes were made with themix, whilst the gtk4 theme is a forked version of a
cattpuccin gtk theme, made to match the colors of the retro futurism design system
I've made.
