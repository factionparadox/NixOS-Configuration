# Diinki Aero

Fork of the <https://github.com/B00merang-Project/Windows-Vista> gtk theme, check it out!
The changes are mainly done to some UI elements in order to better fit in the more modernized design language
for 'diinki aero'

# Updates

I'm likely going to update the GTK theme more as time goes on.
