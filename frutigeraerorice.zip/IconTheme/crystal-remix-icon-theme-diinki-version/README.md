# Crystal Remix icon theme - diinki version

This is a fork of the Crystal Remix icon theme, I will likely edit it, add new icons, and all that; with time.

To install the icon theme, copy the `crystal-remix-icon-theme-diinki-version` directory to `~/.local/share/icons` or `/usr/share/icons`,
and then set the theme to the one in use either with `gsettings` or the `dconf` applications; which you can download with most linux package managers.
